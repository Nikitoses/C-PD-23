﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter the number of points for the figure (3-5):");
        int numPoints = int.Parse(Console.ReadLine());

        if (numPoints < 3 || numPoints > 5)
        {
            Console.WriteLine("The number of points must be between 3 and 5.");
            return;
        }

        Point[] points = new Point[numPoints];

        for (int i = 0; i < numPoints; i++)
        {
            Console.WriteLine($"Enter the X coordinate for point {i + 1}:");
            int x = int.Parse(Console.ReadLine());

            Console.WriteLine($"Enter the Y coordinate for point {i + 1}:");
            int y = int.Parse(Console.ReadLine());

            points[i] = new Point(x, y, $"Point {i + 1}");
        }

        Figure figure = new Figure(points);
        double perimeter = figure.PerimeterCalculator();

        Console.WriteLine($"Figure perimeter: {perimeter}");
    }
}
}